/-
Copyright (c) 2026 Biswajit Mondal. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Biswajit Mondal
-/
import Reinmann.XiToeplitzPositivity
import Mathlib.Data.Nat.Factorial.Basic

/-!
# The Moment-Kernel Mechanism for the Pólya-Frequency Frontier

This file isolates, and *verifies*, the precise analytic mechanism that governs
the unbounded-order Toeplitz (Pólya-frequency) target of `XiToeplitzPositivity`.

**Correctness note (2026-06-06).** `Ξ` is now **Riemann's `ξ`** (see
`JensenProgram`), so Pólya's positive-kernel representation below genuinely applies
(it is a property of `ξ`, false for the earlier `Λ₀` slice).  `XiMomentKernelRep`
states that representation as a **named external classical input** (true, not RH,
not an axiom); the CNV/Pólya facts cited are external and **not formalized here**.

## The unbounded-order obstruction

Riemann's **Pólya integral representation** (classical, elementary, NOT RH):
`Ξ(t) = 2∫₀^∞ Φ(u) cos(ut) du` with `Φ > 0`.  Expanding `cos` gives the Taylor
coefficients as **even moments** of the positive measure `Φ`:

  `XiCoeff n = (-1)^n · 2·Mₙ / (2n)!`,  `Mₙ := ∫₀^∞ Φ(u) u^{2n} du > 0`.

Hence the signed coefficients are `μₙ = (-1)^n·XiCoeff n = 2Mₙ/(2n)! > 0` — the
order-`1` minors are positive *for free*.

The crux: PF positivity needs `μ` to be **Toeplitz** totally positive
(log-concave at order 2, etc.), but the moment sequence `(Mₙ)` is **Hankel**
positive, hence **log-convex** `Mₙ² ≤ M_{n-1}M_{n+1}` — the *wrong* direction.
The factorial weights `(2n)!` carry the entire fight:

  `μₙ²/(μ_{n-1}μ_{n+1}) = (Mₙ²/M_{n-1}M_{n+1}) · ((2n+1)(2n+2)/((2n-1)(2n)))`,

a product of a `≤1` moment factor and a `>1` factorial-slack factor.  Order 1 is
free; order 2 (Turán) is the slack winning narrowly (why CNV needed the explicit
`Φ`). The integral representation *structurally* yields Hankel (not Toeplitz)
positivity. Fixed rank three is not RH-equivalent: the classical sector
baseline already gives nonnegativity through rank 43, and finite real-zero
extraction gives strict contiguous minors at those ranks. See
`research/STRICT_FINITE_PF_FROM_REAL_ZEROS_2026_10_06.md`. Those analytic inputs
remain unformalized; establishing all orders is the RH-equivalent problem.

## What is verified here (honest, non-RH content)

* `weighted_logConcave_iff`, `logConcave_slack_iff` — general algebra of weighted
  log-concavity and the "slack" reweighting (true for all sequences).
* `factorial_slack_nat` / `factorial_slack_real` — the exact factorial identity
  `(2n)!·(2n+4)!·(2n+1)(2n+2) = ((2n+2)!)²·(2n+3)(2n+4)` providing the slack.
* `XiMomentKernelRep` — Pólya's positive-moment representation, stated as a NAMED
  external classical input (not an axiom, not assumed true here).
* `xiMomentCoeff_eq_of_kernelRep`, `xiMomentCoeff_pos_of_kernelRep` — under the
  representation, `μₙ = 2Mₙ/(2n)!` and the order-`1` minors are positive.
* `xiMoment_logConcave_iff_relaxedMoment_of_kernelRep` — under the representation,
  the order-`2` (Turán) minor is **equivalent** to the *relaxed* moment inequality
  `Mₙ·M_{n+2}·(2n+1)(2n+2) ≤ M_{n+1}²·(2n+3)(2n+4)`, exhibiting the slack
  `(2n+3)(2n+4) / ((2n+1)(2n+2)) > 1` explicitly.

None of this proves RH.  It is the verified anatomy of exactly where the open
analysis lives: defeating moment log-convexity by the factorial slack at order
unbounded rank.
-/

noncomputable section

open scoped Nat

namespace Reinmann

/-! ## General algebra: weighted log-concavity and slack reweighting -/

/-- Clearing positive denominators in a weighted log-concavity comparison. -/
theorem weighted_logConcave_iff {a b c wa wb wc : ℝ}
    (hwa : 0 < wa) (hwb : 0 < wb) (hwc : 0 < wc) :
    (a / wa) * (c / wc) ≤ (b / wb) ^ 2 ↔ a * c * wb ^ 2 ≤ b ^ 2 * (wa * wc) := by
  rw [div_mul_div_comm, div_pow, div_le_div_iff₀ (by positivity) (by positivity)]

/-- **Slack reweighting.** If positive weights satisfy `wa·wc·P = wb²·Q`, then a
log-concavity comparison with the `(wa,wb,wc)` weights is equivalent to the same
comparison with the `(P,Q)` weights.  This is the abstract form of trading the
factorial weights for the elementary slack factor. -/
theorem logConcave_slack_iff {x y z wa wb wc P Q : ℝ}
    (hwb : 0 < wb) (hP : 0 < P) (hslack : wa * wc * P = wb ^ 2 * Q) :
    x * y * wb ^ 2 ≤ z ^ 2 * (wa * wc) ↔ x * y * P ≤ z ^ 2 * Q := by
  have hwb2 : 0 < wb ^ 2 := by positivity
  constructor
  · intro h
    nlinarith [mul_nonneg (sub_nonneg.mpr h) hP.le, hslack, hwb2]
  · intro h
    nlinarith [mul_nonneg (sub_nonneg.mpr h) hwb2.le, hslack, hP]

/-! ## The exact factorial slack identity -/

/-- The factorial identity that produces the slack factor:
`(2n)!·(2n+4)!·(2n+1)(2n+2) = ((2n+2)!)²·(2n+3)(2n+4)`. -/
theorem factorial_slack_nat (n : ℕ) :
    (2 * n).factorial * (2 * n + 4).factorial * ((2 * n + 1) * (2 * n + 2))
      = (2 * n + 2).factorial ^ 2 * ((2 * n + 3) * (2 * n + 4)) := by
  have e2 : (2 * n + 2).factorial = (2 * n + 2) * (2 * n + 1) * (2 * n).factorial := by
    rw [show 2 * n + 2 = (2 * n + 1) + 1 from rfl, Nat.factorial_succ, Nat.factorial_succ]
    ring
  have e4 : (2 * n + 4).factorial
      = (2 * n + 4) * (2 * n + 3) * (2 * n + 2).factorial := by
    rw [show 2 * n + 4 = (2 * n + 3) + 1 from rfl, Nat.factorial_succ,
        show 2 * n + 3 = (2 * n + 2) + 1 from rfl, Nat.factorial_succ]
    ring
  rw [e4, e2]; ring

/-- Real-cast form of the factorial slack identity. -/
theorem factorial_slack_real (n : ℕ) :
    ((2 * n).factorial : ℝ) * ((2 * n + 4).factorial : ℝ)
        * (((2 * n + 1) * (2 * n + 2) : ℕ) : ℝ)
      = ((2 * n + 2).factorial : ℝ) ^ 2 * (((2 * n + 3) * (2 * n + 4) : ℕ) : ℝ) := by
  exact_mod_cast factorial_slack_nat n

/-! ## Pólya's positive-moment representation (named external classical input) -/

/-- **Pólya's positive-moment representation of `Ξ`.** There is a positive
sequence `M` (the even moments `∫ Φ·u^{2n}` of Riemann's positive kernel `Φ`)
with `XiCoeff n = (-1)^n · 2·Mₙ / (2n)!`.

This is a *true classical theorem* (it follows from `Φ > 0`, which is elementary),
**not** RH and **not** an axiom — it is a named hypothesis whose Lean proof would
require the Fourier/heat-kernel construction of `Φ`, not yet in Mathlib. -/
def XiMomentKernelRep : Prop :=
  ∃ M : ℕ → ℝ, (∀ n, 0 < M n) ∧
    ∀ n, XiCoeff n = (-1) ^ n * (2 * M n / ((2 * n).factorial : ℝ))

/-- Under the moment representation, the signed coefficient is the bare
factorial-weighted moment: `μₙ = 2Mₙ/(2n)!` (the sign cancels). -/
theorem xiMomentCoeff_eq_of_kernelRep {M : ℕ → ℝ}
    (hM : ∀ n, XiCoeff n = (-1) ^ n * (2 * M n / ((2 * n).factorial : ℝ))) (n : ℕ) :
    XiMomentCoeff n = 2 * M n / ((2 * n).factorial : ℝ) := by
  unfold XiMomentCoeff
  rw [hM n, ← mul_assoc,
      show (-1 : ℝ) ^ n * (-1) ^ n = 1 from by
        rw [← pow_add]; exact Even.neg_one_pow ⟨n, by ring⟩,
      one_mul]

/-- **Order-`1` positivity is free.** Under the moment representation, every signed
moment coefficient is positive. -/
theorem xiMomentCoeff_pos_of_kernelRep {M : ℕ → ℝ}
    (hMpos : ∀ n, 0 < M n)
    (hM : ∀ n, XiCoeff n = (-1) ^ n * (2 * M n / ((2 * n).factorial : ℝ))) (n : ℕ) :
    0 < XiMomentCoeff n := by
  rw [xiMomentCoeff_eq_of_kernelRep hM n]
  apply div_pos
  · linarith [hMpos n]
  · exact_mod_cast (2 * n).factorial_pos

/-! ## The order-`2` rung as a relaxed moment inequality (the slack made explicit) -/

/-- **The mechanism, verified.** Under the moment representation, the order-`2`
Toeplitz/Turán minor of the signed coefficients is *equivalent* to the **relaxed
moment inequality**
`Mₙ·M_{n+2}·(2n+1)(2n+2) ≤ M_{n+1}²·(2n+3)(2n+4)`.

The moments are log-convex (`Mₙ² ≤ M_{n-1}M_{n+1}`, the wrong way); the inequality
holds only because the factorial slack `(2n+3)(2n+4)/((2n+1)(2n+2)) > 1` overcomes
it.  Order `≥ 3` is the same battle at higher order — the genuine open frontier. -/
theorem xiMoment_logConcave_iff_relaxedMoment_of_kernelRep {M : ℕ → ℝ}
    (hM : ∀ n, XiCoeff n = (-1) ^ n * (2 * M n / ((2 * n).factorial : ℝ))) (n : ℕ) :
    XiMomentCoeff n * XiMomentCoeff (n + 2) ≤ XiMomentCoeff (n + 1) ^ 2 ↔
      (M n * M (n + 2)) * (((2 * n + 1) * (2 * n + 2) : ℕ) : ℝ)
        ≤ M (n + 1) ^ 2 * (((2 * n + 3) * (2 * n + 4) : ℕ) : ℝ) := by
  have hfac : ∀ k : ℕ, 0 < ((2 * k).factorial : ℝ) := fun k => by
    exact_mod_cast (2 * k).factorial_pos
  have hP : (0 : ℝ) < (((2 * n + 1) * (2 * n + 2) : ℕ) : ℝ) := by positivity
  have hwb : (0 : ℝ) < ((2 * n + 2).factorial : ℝ) := by exact_mod_cast (2 * n + 2).factorial_pos
  -- rewrite the three signed coefficients via the moment representation
  rw [xiMomentCoeff_eq_of_kernelRep hM n, xiMomentCoeff_eq_of_kernelRep hM (n + 1),
      xiMomentCoeff_eq_of_kernelRep hM (n + 2),
      show 2 * (n + 1) = 2 * n + 2 from by ring, show 2 * (n + 2) = 2 * n + 4 from by ring]
  -- clear denominators to the weighted form
  rw [weighted_logConcave_iff (hfac n) hwb (by exact_mod_cast (2 * n + 4).factorial_pos)]
  -- trade factorial weights for the slack factor
  rw [logConcave_slack_iff hwb hP (factorial_slack_real n)]
  -- cancel the common factor 4 from the doubled moments
  constructor
  · intro h; nlinarith [h]
  · intro h; nlinarith [h]

/-! ## Quantifying the slack: the fight tightens with `n`

The order-`2` slack factor `s_n = (2n+3)(2n+4) / ((2n+1)(2n+2))` is the multiplier
by which the factorial weights relax the moment log-convexity.  It is always `> 1`
(so there is always *some* room), and it **strictly decreases toward `1`** as `n`
grows.  This is the verified quantitative shape of the literature picture: at small
`n` the slack is large (room to spare — the regime CNV closes), while at large `n`
the slack `→ 1`, the near-tie governed by the Griffin–Ono–Rolen–Zagier Hermite
asymptotics.  These are statements of elementary real analysis — *not* RH. -/

/-- The order-`2` factorial slack factor `s_n = (2n+3)(2n+4)/((2n+1)(2n+2))`. -/
def slackFactor (n : ℕ) : ℝ := ((2 * n + 3) * (2 * n + 4)) / ((2 * n + 1) * (2 * n + 2))

/-- There is always room: `s_n > 1`. -/
theorem one_lt_slackFactor (n : ℕ) : 1 < slackFactor n := by
  have hn : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
  unfold slackFactor
  rw [one_lt_div (by positivity)]
  nlinarith [hn]

/-- The slack strictly decreases in `n` (toward `1`): the order-`2` fight tightens. -/
theorem slackFactor_succ_lt (n : ℕ) : slackFactor (n + 1) < slackFactor n := by
  have hn : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
  unfold slackFactor
  rw [div_lt_div_iff₀ (by positivity) (by positivity)]
  push_cast
  nlinarith [hn, sq_nonneg (n : ℝ)]

/-! ## The complete ladder: PF positivity ⟺ factorial-weighted moment determinants

The order-`2` slack is special (a scalar factor); higher orders do not collapse to a
scalar.  The *complete* general reduction is determinantal: at **every** order `k`
and offset `m`, the Pólya-frequency (Toeplitz) minor of the signed coefficients
equals `2^k` times the determinant of the **factorial-weighted moment** matrix
`[ M_{i-j} / (2(i-j))! ]`.  So PF positivity at all orders — i.e. RH, via
`XiToeplitzPositivity` — is *exactly* positivity of these moment determinants: the
concrete-analytic target on Pólya's kernel `Φ`, ladder-complete. -/

/-- Factorial-weighted moment Toeplitz entry: `M_{i-j}/(2(i-j))!` for `j ≤ i`. -/
def momentToeplitzEntry (M : ℕ → ℝ) (i j : ℕ) : ℝ :=
  if j ≤ i then M (i - j) / ((2 * (i - j)).factorial : ℝ) else 0

/-- The factorial-weighted moment sequence that appears in the Toeplitz/PF
determinants. -/
def weightedMoment (M : ℕ → ℝ) (n : ℕ) : ℝ :=
  M n / ((2 * n).factorial : ℝ)

theorem momentToeplitzEntry_sub (M : ℕ → ℝ) (i j : ℕ) (h : j ≤ i) :
    momentToeplitzEntry M i j = weightedMoment M (i - j) := if_pos h

/-- The order-`k`, offset-`m` factorial-weighted moment Toeplitz minor. -/
def momentToeplitzContigMinor (M : ℕ → ℝ) (k m : ℕ) : ℝ :=
  (Matrix.of (fun i j : Fin k => momentToeplitzEntry M (m + i.val) j.val)).det

/-- Each signed-coefficient Toeplitz entry is `2 ×` the moment-weighted entry. -/
theorem xiToeplitzEntry_eq_two_mul_moment_of_kernelRep {M : ℕ → ℝ}
    (hM : ∀ n, XiCoeff n = (-1) ^ n * (2 * M n / ((2 * n).factorial : ℝ))) (i j : ℕ) :
    XiToeplitzEntry i j = 2 * momentToeplitzEntry M i j := by
  unfold XiToeplitzEntry momentToeplitzEntry
  split_ifs with h
  · rw [xiMomentCoeff_eq_of_kernelRep hM]; ring
  · ring

/-- **Complete ladder (identity).** Under the moment representation, the order-`k`
Toeplitz minor of the signed coefficients is `2^k` times the factorial-weighted
moment Toeplitz minor — at every order `k` and offset `m`. -/
theorem xiToeplitzContigMinor_eq_of_kernelRep {M : ℕ → ℝ}
    (hM : ∀ n, XiCoeff n = (-1) ^ n * (2 * M n / ((2 * n).factorial : ℝ))) (k m : ℕ) :
    XiToeplitzContigMinor k m = 2 ^ k * momentToeplitzContigMinor M k m := by
  have hmat : (Matrix.of (fun i j : Fin k => XiToeplitzEntry (m + i.val) j.val))
      = (2 : ℝ) • Matrix.of (fun i j : Fin k => momentToeplitzEntry M (m + i.val) j.val) := by
    ext i j
    simp only [Matrix.of_apply, Matrix.smul_apply, smul_eq_mul]
    exact xiToeplitzEntry_eq_two_mul_moment_of_kernelRep hM _ _
  unfold XiToeplitzContigMinor momentToeplitzContigMinor
  rw [hmat, Matrix.det_smul, Fintype.card_fin]

/-- **Complete ladder (positivity).** Under the moment representation, the
Pólya-frequency positivity of the signed coefficients at *every* order is
equivalent to positivity of the factorial-weighted moment Toeplitz determinants.
This is the full concrete-analytic ladder: RH (via PF positivity) ⟺ positivity of
explicit moment determinants of Pólya's kernel `Φ`, at all orders. -/
theorem xiToeplitzContigMinor_nonneg_iff_moment_of_kernelRep {M : ℕ → ℝ}
    (hM : ∀ n, XiCoeff n = (-1) ^ n * (2 * M n / ((2 * n).factorial : ℝ))) (k m : ℕ) :
    0 ≤ XiToeplitzContigMinor k m ↔ 0 ≤ momentToeplitzContigMinor M k m := by
  rw [xiToeplitzContigMinor_eq_of_kernelRep hM]
  exact mul_nonneg_iff_of_pos_left (by positivity)

/-! ## The order-`3` frontier as a kernel determinant target -/

/-- Kernel-side form of the first non-Turán frontier target: every order-`3`
factorial-weighted moment Toeplitz determinant is nonnegative at the xi offsets
corresponding to `XiToeplitzMinor3`. -/
def MomentToeplitzOrder3Positive (M : ℕ → ℝ) : Prop :=
  ∀ n : ℕ, 0 ≤ momentToeplitzContigMinor M 3 (n + 2)

/-- Explicit algebraic expansion of the order-`3` factorial-weighted moment
Toeplitz determinant.  This is the concrete inequality to attack analytically
for the first non-Turán rung. -/
theorem momentToeplitzOrder3_eq (M : ℕ → ℝ) (n : ℕ) :
    momentToeplitzContigMinor M 3 (n + 2) =
      weightedMoment M (n + 2) *
          (weightedMoment M (n + 2) ^ 2
            - weightedMoment M (n + 1) * weightedMoment M (n + 3))
        - weightedMoment M (n + 1) *
          (weightedMoment M (n + 3) * weightedMoment M (n + 2)
            - weightedMoment M (n + 1) * weightedMoment M (n + 4))
        + weightedMoment M n *
          (weightedMoment M (n + 3) ^ 2
            - weightedMoment M (n + 2) * weightedMoment M (n + 4)) := by
  unfold momentToeplitzContigMinor
  rw [Matrix.det_fin_three]
  simp only [Matrix.of_apply, Fin.val_zero, Fin.val_one]
  rw [show (2 : Fin 3).val = 2 from rfl,
      momentToeplitzEntry_sub M (n + 2 + 0) 0 (by omega),
      momentToeplitzEntry_sub M (n + 2 + 1) 1 (by omega),
      momentToeplitzEntry_sub M (n + 2 + 2) 2 (by omega),
      momentToeplitzEntry_sub M (n + 2 + 0) 1 (by omega),
      momentToeplitzEntry_sub M (n + 2 + 1) 2 (by omega),
      momentToeplitzEntry_sub M (n + 2 + 2) 0 (by omega),
      momentToeplitzEntry_sub M (n + 2 + 0) 2 (by omega),
      momentToeplitzEntry_sub M (n + 2 + 1) 0 (by omega),
      momentToeplitzEntry_sub M (n + 2 + 2) 1 (by omega),
      show n + 2 + 0 - 0 = n + 2 from rfl,
      show n + 2 + 1 - 1 = n + 2 from by omega,
      show n + 2 + 2 - 2 = n + 2 from by omega,
      show n + 2 + 0 - 1 = n + 1 from by omega,
      show n + 2 + 1 - 2 = n + 1 from by omega,
      show n + 2 + 2 - 0 = n + 4 from by omega,
      show n + 2 + 0 - 2 = n from by omega,
      show n + 2 + 1 - 0 = n + 3 from by omega,
      show n + 2 + 2 - 1 = n + 3 from by omega]
  ring

/-- The order-`3` determinant normalized by the central scale
`weightedMoment M (n+2)^3`.  Numerically this is the right diagnostic because raw
determinants shrink at the factorial scale of the xi coefficients. -/
def normalizedMomentToeplitzOrder3 (M : ℕ → ℝ) (n : ℕ) : ℝ :=
  momentToeplitzContigMinor M 3 (n + 2) / weightedMoment M (n + 2) ^ 3

/-- The adjacent-ratio expression for the normalized order-`3` determinant. -/
def momentToeplitzOrder3RatioExpr (M : ℕ → ℝ) (n : ℕ) : ℝ :=
  let c := weightedMoment M (n + 2)
  let x := weightedMoment M (n + 1) / c
  let y := weightedMoment M n / c
  let z := weightedMoment M (n + 3) / c
  let w := weightedMoment M (n + 4) / c
  1 - 2 * x * z - y * w + x ^ 2 * w + y * z ^ 2

/-- Under Pólya's moment representation, the coefficient-side order-`3`
Toeplitz target is exactly the kernel-side order-`3` determinant target. -/
theorem xiToeplitzOrder3Positive_iff_moment_of_kernelRep {M : ℕ → ℝ}
    (hM : ∀ n, XiCoeff n = (-1) ^ n * (2 * M n / ((2 * n).factorial : ℝ))) :
    XiToeplitzOrder3Positive ↔ MomentToeplitzOrder3Positive M := by
  unfold XiToeplitzOrder3Positive MomentToeplitzOrder3Positive
  constructor
  · intro h n
    have hminor : 0 ≤ XiToeplitzMinor3 n := h n
    rwa [xiToeplitzMinor3_eq_contig,
      xiToeplitzContigMinor_nonneg_iff_moment_of_kernelRep hM 3 (n + 2)] at hminor
  · intro h n
    have hminor : 0 ≤ momentToeplitzContigMinor M 3 (n + 2) := h n
    rw [xiToeplitzMinor3_eq_contig]
    rwa [xiToeplitzContigMinor_nonneg_iff_moment_of_kernelRep hM 3 (n + 2)]

end Reinmann
